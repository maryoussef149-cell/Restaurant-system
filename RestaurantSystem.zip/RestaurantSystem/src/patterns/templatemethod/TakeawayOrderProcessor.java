package patterns.templatemethod;

import core.model.Order;
import core.model.Pizza;
import core.model.Burger;

public class TakeawayOrderProcessor extends OrderProcessingTemplate {
    
    @Override
    protected void applyOrderTypeSpecificCharges(Order order) {
        double packagingFee = 1.00;
        order.addCharge(packagingFee, "Packaging Fee");
        System.out.printf("Packaging Fee: ", packagingFee);
    }

    @Override
    protected void generateFinalReceipt(Order order) {
        System.out.println("\nTAKEAWAY RECEIPT ");
        System.out.println("Order ID: " + order.getOrderId());
        System.out.println("Customer ID: " + order.getCustomerId());
        
        order.getItems().forEach(lineItem -> {
            if (lineItem.getItem() instanceof Pizza) {
                Pizza pizza = (Pizza) lineItem.getItem();
                System.out.println("Item: " + pizza.getName() + " x" + lineItem.getQuantity() + " | Dough: " + pizza.getDough() + ", Sauce: " + pizza.getSauce());
            } else if (lineItem.getItem() instanceof Burger) {
                 Burger burger = (Burger) lineItem.getItem();
                System.out.println("Item: " + burger.getName() + " x" + lineItem.getQuantity() + " | Patty: " + burger.getPattyType() + ", Bun: " + burger.getBunType() + ", Addons: " + burger.getAddons().size());
            } else {
                 System.out.println("Item: " + lineItem.getItem().getName() + " x" + lineItem.getQuantity());
            }
        });

        System.out.printf("Subtotal: ", order.getPreDiscountTotal());
        System.out.printf("Tax: ", order.getTax());
        order.getCharges().forEach(System.out::println);
        System.out.printf("FINAL AMOUNT DUE: ", order.getFinalTotal());
    }
}