package patterns.templatemethod;

import core.model.Order;
import patterns.chainofresponsibility.*;
import core.exceptions.OrderException;

public abstract class OrderProcessingTemplate {
    
    public final void processOrder(Order order) {
        if (order.getPreDiscountTotal() <= 0) {
            throw new OrderException("Cannot process empty or zero-value order: " + order.getOrderId());
        }

        System.out.println("--- Starting Order Processing for Order " + order.getOrderId() + " (Customer: " + order.getCustomerId() + ") ---");
        
        order.updateTotals(); 
        
        System.out.printf("Initial Subtotal:", order.getPreDiscountTotal(), order.getTax());
        System.out.printf("Initial Total (Pre-Discount & Pre-Charge): %.2f%n", order.getFinalTotal());
        
        applyOrderTypeSpecificCharges(order); 
        
        applyDiscounts(order);
        
        generateFinalReceipt(order);
        
        System.out.println("--- Order Processing Completed ---");
    }
    
    protected abstract void applyOrderTypeSpecificCharges(Order order);
    protected abstract void generateFinalReceipt(Order order);

    private void applyDiscounts(Order order) {
        System.out.println("Applying Discounts:");
        DiscountHandler itemDisc = new CustomerLoyaltyDiscountHandler();
        DiscountHandler minDisc = new MinimumOrderDiscountHandler();
        
        itemDisc.setNextHandler(minDisc); 
        
        double finalTotal = itemDisc.apply(order, order.getFinalTotal());
        
        if (finalTotal < 0) {
             throw new OrderException("error calculating final total for order: " + order.getOrderId());
        }
        order.setFinalTotal(finalTotal);
    }
}