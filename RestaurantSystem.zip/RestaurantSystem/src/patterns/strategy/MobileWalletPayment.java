package patterns.strategy;

import core.exceptions.PaymentProcessingException;

public class MobileWalletPayment implements IPaymentStrategy {
    private String phoneNumber;

    public MobileWalletPayment(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public boolean processPayment(double amount) throws PaymentProcessingException {
        if (amount > 500.0) {
            throw new PaymentProcessingException("Mobile Wallet limit exceeded for transaction amount: " + String.format("%.2f", amount));
        }
        
        System.out.printf("Sending notification to Mobile Wallet Amount: $%.2f%n", phoneNumber, amount);
        return true; 
    }
}