package patterns.strategy;

import core.exceptions.PaymentProcessingException;
import java.io.IOException;

public class CreditCardPayment implements IPaymentStrategy {
    private String cardNumber;

    public CreditCardPayment(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    @Override
    public boolean processPayment(double amount) throws PaymentProcessingException {
        // Simulate a scenario where external communication fails 
        if (cardNumber.endsWith("0000")) {
             try {
                 throw new IOException("Gateway server timed out.");
             } catch (IOException e) {
                 // Wrap the checked IOException in checked PaymentProcessingException
                 throw new PaymentProcessingException("Credit card processing failed: " + e.getMessage(), e);
             }
        }
        
        System.out.println("payment Processing $" + amount);
        return true; 
    }
}