package patterns.chainofresponsibility;

import core.model.Order;

public class ItemCategoryDiscountHandler extends DiscountHandler {
    @Override
    public double apply(Order order, double currentTotal) {
        double chickenDiscountRate = 0.15; 
        double chickenSubtotal = order.calculateSubTotalByCategory("Chicken");
        double discountAmount = chickenSubtotal * chickenDiscountRate;
        
        double newTotal = currentTotal - discountAmount;
        if (discountAmount > 0) {
            double roundedDiscount = roundToTwoDecimals(discountAmount);
            System.out.println("   - Applied Chicken Discount (15%): "+ roundedDiscount);
        }

        if (nextHandler != null) {
            return nextHandler.apply(order, newTotal);
        }
        return newTotal;
    }
}