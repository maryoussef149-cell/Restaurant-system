package patterns.chainofresponsibility;

import core.model.Order;

public abstract class DiscountHandler {
    protected DiscountHandler nextHandler;

    public void setNextHandler(DiscountHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    public abstract double apply(Order order, double currentTotal);
}