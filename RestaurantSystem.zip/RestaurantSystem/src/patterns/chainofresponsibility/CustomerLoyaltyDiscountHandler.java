package patterns.chainofresponsibility;

import core.model.Order;

public class CustomerLoyaltyDiscountHandler extends DiscountHandler {
    @Override
    public double apply(Order order, double currentTotal) {
        double discountAmount = 0.0;
        if (order.getCustomerId().endsWith("1")) {
            discountAmount = currentTotal * 0.05; 
            System.out.printf("Loyalty Discount (5% off): ", discountAmount);
        }

        double newTotal = currentTotal - discountAmount;
        
        if (nextHandler != null) {
            return nextHandler.apply(order, newTotal);
        }
        return newTotal;
    }
}