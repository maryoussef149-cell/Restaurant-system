package patterns.observer;

public interface IOrderSubject {
    void attach(IOrderObserver observer);
    void detach(IOrderObserver observer);
    void notifyObservers();
}