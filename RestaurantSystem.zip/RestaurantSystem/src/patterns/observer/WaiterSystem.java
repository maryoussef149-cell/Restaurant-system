package patterns.observer;

import core.model.Order;

public class WaiterSystem implements IOrderObserver {
    @Override
    public void update(Order order) {
        if (order.getStatus().equals("PLACED")) {
            System.out.println("Waiter System Notified. Order " + order.getOrderId() + " is ready for service/delivery.");
        }
    }
}