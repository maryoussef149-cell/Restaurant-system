package patterns.observer;

import core.model.Order;

public class KitchenSystem implements IOrderObserver {
    @Override
    public void update(Order order) {
        if (order.getStatus().equals("PLACED")) {
            System.out.println("NEW ORDER RECEIVED! Order ID: " + order.getOrderId());
        }
    }
}