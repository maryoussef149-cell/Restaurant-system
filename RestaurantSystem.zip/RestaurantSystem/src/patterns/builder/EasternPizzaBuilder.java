package patterns.builder;

import core.model.Pizza;
import java.util.*;

public class EasternPizzaBuilder implements IPizzaBuilder {
    private Pizza pizza;

    public EasternPizzaBuilder() {
        this.pizza = new Pizza("Eastern Pizza", 8.0); 
    }

    @Override
    public void buildDough(String type) { pizza.setDough("Hand-stretched Thin Crust"); }
    @Override
    public void buildSauce(String type) { pizza.setSauce("Spicy Harissa Base"); }
    
    @Override
    public void addToppings(List<String> toppings) { 
        List<String> combinedToppings = new ArrayList<>();
        combinedToppings.add("Minced Lamb"); // Default
        combinedToppings.addAll(toppings); // Custom
        pizza.setToppings(combinedToppings);
    }
    
    @Override
    public void setSize(String size) { 
        double cost = size.equals("Large") ? 7.0 : 4.0;
        pizza.setSizeCost(cost); 
    }

    @Override
    public Pizza getResult() { return this.pizza; }
}