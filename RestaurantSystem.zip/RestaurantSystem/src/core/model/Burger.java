package core.model;

import java.util.List;
import java.util.ArrayList;

public class Burger extends MenuItem {
    private String pattyType;
    private String bunType;
    private List<String> addons = new ArrayList<>();
    private double pattyCost;

    public Burger(String name, double basePrice) {
        super(name, basePrice);
    }

    public void setPattyType(String type) { this.pattyType = type; }
    public void setBunType(String type) { this.bunType = type; }
    public void setAddons(List<String> list) { this.addons = list; }
    public void setPattyCost(double cost) { this.pattyCost = cost; }

    public String getPattyType() { return pattyType; }
    public String getBunType() { return bunType; }
    public List<String> getAddons() { return addons; }
    
    @Override
    public double calculatePrice() {
        return getBasePrice() + pattyCost + (addons.size() * 1.0);
    }
}