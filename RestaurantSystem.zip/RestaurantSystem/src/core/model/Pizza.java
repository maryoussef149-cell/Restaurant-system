package core.model;

import java.util.List;
import java.util.ArrayList;

public class Pizza extends MenuItem {
    private String dough;
    private String sauce;
    private List<String> toppings = new ArrayList<>();
    private double sizeCost;

    public Pizza(String name, double basePrice) {
        super(name, basePrice);
    }
    
    public void setDough(String d) { this.dough = d; }
    public void setSauce(String s) { this.sauce = s; }
    public void setToppings(List<String> t) { this.toppings = t; }
    public void setSizeCost(double cost) { this.sizeCost = cost; }

    public String getDough() { return dough; }
    public String getSauce() { return sauce; }

    @Override
    public double calculatePrice() {
        return getBasePrice() + sizeCost + (toppings.size() * 1.0);
    }
    public List<String> getToppings() { return toppings; } 
    public double getSizeCost() { return sizeCost; } 
}