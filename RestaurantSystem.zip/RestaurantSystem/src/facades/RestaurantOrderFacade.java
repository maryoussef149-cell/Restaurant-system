package facades;

import core.model.Order;
import core.model.Pizza;
import core.model.Burger;
import core.services.OrderService;
import patterns.builder.*;
import patterns.strategy.IPaymentStrategy;
import patterns.templatemethod.*;
import core.exceptions.PaymentProcessingException;
import core.exceptions.OrderException;

import java.util.List;

public class RestaurantOrderFacade {
    public OrderService orderService = new OrderService();
    private OrderDirector orderDirector = new OrderDirector();

    public Order createAndCustomizeOrder(String customerId, String menuType, List<String> addons, String size) throws OrderException {
        Order order = orderService.startNewOrder(customerId);

        if ("EasternPizza".equals(menuType)) {
            IPizzaBuilder builder = new EasternPizzaBuilder();
            Pizza customPizza = orderDirector.constructCustomPizza(builder, size, addons);
            order.addItem(customPizza, 1);
            System.out.println("Added customized item: " + customPizza.getName() + " with toppings: " + customPizza.getToppings());
        } else if ("ClassicBurger".equals(menuType)) { 
            IBurgerBuilder builder = new ClassicBurgerBuilder();
            Burger customBurger = orderDirector.constructCustomBurger(builder, addons);
            order.addItem(customBurger, 1);
            System.out.println("Added customized item: " + customBurger.getName() + " with " + customBurger.getAddons().size() + " addons.");
        }
        
        order.updateTotals();
        return order;
    }
    
    public void executeWorkflow(Order order, String orderType, IPaymentStrategy paymentMethod) throws OrderException {
        
        try {
            OrderProcessingTemplate processor;
            
            if (orderType.equalsIgnoreCase("Delivery")) {
                processor = new DeliveryOrderProcessor();
            } else if (orderType.equalsIgnoreCase("Dine-In")) {
                processor = new DineInOrderProcessor();
            } else if (orderType.equalsIgnoreCase("Takeaway")) { 
                processor = new TakeawayOrderProcessor();
            } else {
                 throw new OrderException("Invalid order type selected: " + orderType);
            }

            processor.processOrder(order);

            System.out.println("\nInitiating payment...");
            
            boolean paid = paymentMethod.processPayment(order.getFinalTotal());

            if (paid) {
                order.placeOrder(); 
            } else {
                System.out.println("Payment failed. Order status PENDING.");
            }
        } catch (PaymentProcessingException e) {
            System.err.println("\nOrder " + order.getOrderId() + "payment failed: " + e.getMessage());
            System.err.println("Order status remains PENDING. Try alternate payment.");
        } catch (OrderException e) {
            System.err.println("\nOrder Logic Failure: " + e.getMessage());
            throw e; 
        }
    }
}