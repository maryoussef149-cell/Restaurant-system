import core.model.Order;
import core.model.MenuItem;
import facades.RestaurantOrderFacade;
import patterns.observer.KitchenSystem;
import patterns.observer.WaiterSystem;
import patterns.strategy.CreditCardPayment;
import patterns.strategy.MobileWalletPayment;
import patterns.strategy.CashPayment;
import patterns.strategy.IPaymentStrategy;
import core.exceptions.OrderException;

import java.util.Arrays;

public class Application {
    
    // Instantiate Observers
    private static final KitchenSystem kitchen = new KitchenSystem();
    private static final WaiterSystem waiter = new WaiterSystem();
    
    // Instantiate the Facade
    private static final RestaurantOrderFacade facade = new RestaurantOrderFacade();

    public static void main(String[] args) {

        // SCENARIO 1: DELIVERY ORDER with Loyalty Discount
        testScenario1();

        // SCENARIO 2: TAKEAWAY ORDER with Minimum Order Discount and Cash Payment
        testScenario2();

        // SCENARIO 3: FAILURE TEST (Mobile Wallet Limit Exceeded)  
        testScenario3();
    }

    private static void testScenario1() {
        try {
            System.out.println("SCENARIO 1: DELIVERY (Loyalty, Item Discount)");

            // Customer ID ends with '1' to trigger Loyalty Discount
            String customerId = "101"; 
            
            // 1. Create a Pizza with Chicken (triggers Category Discount)
            Order order = facade.createAndCustomizeOrder(
                customerId, 
                "EasternPizza", 
                Arrays.asList("olives", "chicken", "onions"), 
                "Large" // Price: $8.00 (Base) + $7.00 (Size) + 3 * $1.50 (Toppings) = $19.50
            ); 
            
            // 2. Add an expensive Burger (to increase subtotal)
            order.addItem(facade.createAndCustomizeOrder(
                customerId, 
                "ClassicBurger", 
                Arrays.asList("bacon", "extra cheese", "mayo"),
                "N/A"
            ).getItems().get(0).getItem(), 1); // Price: $7.50 (Base) + $5.00 (Patty) + 4 * $1.00 (Addons) = $16.50
            
            // Subtotal: 19.50 + 16.50 = 36.00 (Low total to avoid Min Order Discount)
            
            // 3. Attach Observers
            order.attach(kitchen);
            order.attach(waiter);
            
            // 4. Select Payment Strategy (Credit Card)
            IPaymentStrategy payment = new CreditCardPayment("4511-2222-3333-4444");

            // 5. Execute Workflow (Delivery)
            facade.executeWorkflow(order, "Delivery", payment);
            
        } catch (OrderException e) {
            System.err.println("EXECUTION STOPPED FOR SCENARIO 1 DUE TO CRITICAL ERROR: " + e.getMessage());
        }
    }

    private static void testScenario2() {
        try {
            System.out.println("SCENARIO 2: TAKEAWAY (Min Order Discount, Cash)");

            String customerId = "202"; 

            // 1. Create 5 Large Pizzas to easily exceed the $100 Minimum Discount threshold
            Order order = facade.createAndCustomizeOrder(
                customerId, 
                "EasternPizza", 
                Arrays.asList("beef", "peppers"), 
                "Large"
            ); 
            // Add 4 more units of the same Pizza item (Total 5 Pizzas)
            for(int i = 0; i < 4; i++) {
                 order.addItem(facade.createAndCustomizeOrder(
                    customerId, 
                    "EasternPizza", 
                    Arrays.asList("beef", "peppers"), 
                    "Large"
                ).getItems().get(0).getItem(), 1);
            }
            // 1 Pizza price: $8.00 + $7.00 + 3*$1.50 = $19.50
            // Subtotal: 5 * 19.50 = $97.50 (add one salad to push it over $100)
            
            order.addItem(new MenuItem("Large Family Salad", 15.0) {
                 @Override public double calculatePrice() { return getBasePrice(); }
            }, 1);
            // New Subtotal: $97.50 + $15.00 = $112.50 (Triggers Minimum Order Discount)

            // 2. Attach Observers
            order.attach(kitchen);
            order.attach(waiter);
            
            // 3. Select Payment Strategy (Cash)
            IPaymentStrategy payment = new CashPayment();

            // 4. Execute Workflow (Takeaway)
            facade.executeWorkflow(order, "Takeaway", payment);
            
        } catch (OrderException e) {
            System.err.println("EXECUTION STOPPED FOR SCENARIO 2 DUE TO CRITICAL ERROR: " + e.getMessage());
        }
    }
    
    private static void testScenario3() {
        try {
            System.out.println("SCENARIO 3: FAILURE TEST (Mobile Wallet Limit)");

            String customerId = "303"; 

            // 1. Create a high-value order designed to exceed the Mobile Wallet limit ($500)
            Order order = facade.createAndCustomizeOrder(
                customerId, 
                "EasternPizza", 
                Arrays.asList("gold leaf"), 
                "Large"
            ); 
            // Add items to push total well over $500
            order.addItem(new MenuItem("Billionaire Steak Platter", 200.0) {
                @Override public double calculatePrice() { return getBasePrice(); }
            }, 3); 
            // Initial Subtotal is well over $500

            // 2. Observers are attached but won't be notified if payment fails
            order.attach(kitchen);
            order.attach(waiter);
            
            // 3. Select Payment Strategy (Mobile Wallet)
            MobileWalletPayment payment = new MobileWalletPayment("555-500-0000");

            // 4. Execute Workflow (Dine-In) - This will fail at the payment step
            facade.executeWorkflow(order, "Dine-In", payment);
            
        } catch (OrderException e) {
            // This is where the successful execution should end for this scenario
            System.err.println("EXECUTION STOPPED: " + e.getMessage());
        }
    }
}