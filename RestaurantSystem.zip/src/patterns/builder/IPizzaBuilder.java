package patterns.builder;

import core.model.Pizza;
import java.util.List;

public interface IPizzaBuilder {
    void buildDough(String type);
    void buildSauce(String type);
    void addToppings(List<String> toppings);
    void setSize(String size);
    Pizza getResult();
}