package patterns.builder;

import core.model.Pizza;
import core.model.Burger;
import java.util.List;

public class OrderDirector {
    
    public Pizza constructCustomPizza(IPizzaBuilder builder, String size, List<String> customToppings) {
        builder.buildDough(null); 
        builder.buildSauce(null);
        builder.addToppings(customToppings);
        builder.setSize(size);
        return builder.getResult();
    }
    
    public Burger constructCustomBurger(IBurgerBuilder builder, List<String> customAddons) {
        builder.buildPatty(null);
        builder.buildBun(null);
        builder.addAddons(customAddons);
        return builder.getResult();
    }
}