package patterns.builder;

import core.model.Burger;
import java.util.*;

public class ClassicBurgerBuilder implements IBurgerBuilder {
    private Burger burger;

    public ClassicBurgerBuilder() {
        this.burger = new Burger("Classic Burger", 7.50); 
    }

    @Override
    public void buildPatty(String type) { 
        this.burger.setPattyType("Beef Patty");
        this.burger.setPattyCost(5.0); 
    }
    
    @Override
    public void buildBun(String type) { 
        this.burger.setBunType("Brioche Bun");
    }
    
    @Override
    public void addAddons(List<String> addons) { 
        List<String> combinedAddons = new ArrayList<>();
        combinedAddons.add("Lettuce"); // Default
        combinedAddons.addAll(addons); // Custom
        burger.setAddons(combinedAddons);
    }
    
    @Override
    public Burger getResult() { return this.burger; }
}