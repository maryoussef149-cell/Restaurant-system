package patterns.builder;

import core.model.Burger;
import java.util.List;

public interface IBurgerBuilder {
    void buildPatty(String type);
    void buildBun(String type);
    void addAddons(List<String> addons);
    Burger getResult();
}