package patterns.strategy;

import core.exceptions.PaymentProcessingException;

public class CashPayment implements IPaymentStrategy {
    
    @Override
    public boolean processPayment(double amount) throws PaymentProcessingException {
        System.out.println("Cash payment accepted. Amount:" + amount);
        return true; 
    }
}