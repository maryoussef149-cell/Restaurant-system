package patterns.strategy;

import core.exceptions.PaymentProcessingException;

public interface IPaymentStrategy {
    // Declaring a checked exception to signal external failure possibilities
    boolean processPayment(double amount) throws PaymentProcessingException;
}