package patterns.chainofresponsibility;

import core.model.Order;
import java.lang.Math;

public abstract class DiscountHandler {
    protected DiscountHandler nextHandler;

    public void setNextHandler(DiscountHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    public abstract double apply(Order order, double currentTotal);
    
    protected static double roundToTwoDecimals(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}