package patterns.chainofresponsibility;

import core.model.Order;

public class MinimumOrderDiscountHandler extends DiscountHandler {
    @Override
    public double apply(Order order, double currentTotal) {
        double discountAmount = 0.0;
        if (order.getPreDiscountTotal() >= 100.0) {
            discountAmount = 10.0;
            double roundedDiscount = roundToTwoDecimals(discountAmount);
            System.out.println("Minimum Order Discount ($10 off): "+ roundedDiscount);
        }

        double newTotal = currentTotal - discountAmount;
        
        if (nextHandler != null) {
            return nextHandler.apply(order, newTotal);
        }
        return newTotal;
    }
}