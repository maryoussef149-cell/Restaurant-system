package patterns.observer;

import core.model.Order;

public interface IOrderObserver {
    void update(Order order);
}