import core.model.Order;
import core.model.MenuItem;
import facades.RestaurantOrderFacade;
import patterns.observer.KitchenSystem;
import patterns.observer.WaiterSystem;
import patterns.strategy.CreditCardPayment;
import patterns.strategy.MobileWalletPayment;
import patterns.strategy.CashPayment;
import patterns.strategy.IPaymentStrategy;
import core.exceptions.OrderException;

import java.util.*;
import java.util.stream.Collectors;

public class Application {
    
    private static final Scanner scanner = new Scanner(System.in);
    private static final RestaurantOrderFacade facade = new RestaurantOrderFacade();
    private static final KitchenSystem kitchen = new KitchenSystem();
    private static final WaiterSystem waiter = new WaiterSystem();

    public static void main(String[] args) {
        System.out.println("=================================================");
        System.out.println(" RESTAURANT ORDERING SYSTEM ");
        System.out.println("=================================================");

        try {
            interactiveOrderProcess();
        } catch (Exception e) {
            System.err.println("\nApplication encountered an unexpected error.");
            System.err.println("Details: " + e.getMessage());
        } finally {
            if (scanner != null) {
                scanner.close();
            }
        }
    }
    
    private static void interactiveOrderProcess() throws OrderException {
        System.out.print("Enter your Customer ID (e.g., CUST101 for Loyalty Test): ");
        String customerId = scanner.nextLine().trim();

        Order currentOrder = new Order("TEMP", customerId);
        
        currentOrder.attach(kitchen);
        currentOrder.attach(waiter);

        System.out.println("Order started successfully for customer: " + customerId);
        
        while (true) {
            displayMenu(currentOrder); 
            System.out.print("Enter choice (1-4) or 'C' to Checkout: ");
            String choice = scanner.nextLine().toUpperCase();

            if (choice.equals("C")) {
                if (currentOrder.getPreDiscountTotal() == 0) {
                    System.out.println("[WARNING] Cannot checkout with an empty order. Please select an item.");
                    continue;
                }
                break;
            }
            
            try {
                handleMenuItemSelection(currentOrder, choice);
            } catch (OrderException e) {
                System.err.println("[ERROR] " + e.getMessage());
            } catch (Exception e) {
                System.err.println("[ERROR] Invalid input or unexpected error during selection: " + e.getMessage());
            }
        }
        
        String orderType = getOrderType();
        IPaymentStrategy paymentStrategy = getPaymentStrategy();
        
        Order finalOrder = facade.orderService.startNewOrder(currentOrder.getCustomerId());
        
        currentOrder.getItems().forEach(item -> 
            finalOrder.addItem(item.getItem(), item.getQuantity())
        );
        
        finalOrder.attach(kitchen);
        finalOrder.attach(waiter);
        
        try {
            System.out.println("\n--- FINALIZING ORDER ---");
            facade.executeWorkflow(finalOrder, orderType, paymentStrategy);
            System.out.println(" Order successfully initiated/placed!");
        } catch (OrderException e) {
            System.err.println("\n[ORDER FAILED] Cannot execute order: " + e.getMessage());
        }
    }

    private static void displayMenu(Order order) {
        System.out.println("\n---  Menu Display  ---");
        System.out.println("1. Eastern Pizza (Customizable: Base 8.00)");
        System.out.println("2. Classic Burger (Customizable: Base 7.50)");
        System.out.println("3. Chicken Breast Meal (25.00) (for Item Discount)");
        System.out.println("4. Side Salad (12.00)");
        System.out.println("C. Proceed to Checkout");
        
        order.updateTotals(); 
        System.out.println("[STATUS] Current Subtotal (Pre-Tax/Discount): " + order.getPreDiscountTotal());
    }

    private static void handleMenuItemSelection(Order order, String choice) throws OrderException {
        
        List<String> customAddons = new ArrayList<>();
        String inputLine;

        switch (choice) {
            case "1": 
                System.out.print("Enter desired size (Small/Large, default Small): ");
                String size = scanner.nextLine().trim();
                size = size.equalsIgnoreCase("Large") ? "Large" : "Small";

                System.out.print("Enter toppings (comma-separated, e.g., 'olives,chicken',and write none if you don't want any): ");
                inputLine = scanner.nextLine();
                if(Objects.equals(inputLine, "none") || Objects.equals(inputLine, "None")) {
                    Order itemOrder = facade.createAndCustomizeOrder(order.getCustomerId(), "EasternPizza", customAddons, size);
                    order.addItem(itemOrder.getItems().get(0).getItem(), 1);
                    System.out.println("Added Pizza (Size: " + size + "). Addons: " + customAddons.size());
                    break;
                }
                customAddons = Arrays.asList(inputLine.split(",")).stream()
                                            .map(String::trim)
                                            .filter(s -> !s.isEmpty())
                                            .collect(Collectors.toList());
                
                Order itemOrder = facade.createAndCustomizeOrder(order.getCustomerId(), "EasternPizza", customAddons, size);
                order.addItem(itemOrder.getItems().get(0).getItem(), 1);
                System.out.println("Added Pizza (Size: " + size + "). Addons: " + customAddons.size());
                break;
                
            case "2": 
                System.out.print("Enter addons (comma-separated, e.g., 'bacon,extra cheese',and write none if you don't want any): ");
                inputLine = scanner.nextLine();
                if(Objects.equals(inputLine, "none") || Objects.equals(inputLine, "None")) {
                    Order burgerOrder = facade.createAndCustomizeOrder(order.getCustomerId(), "ClassicBurger", customAddons, "N/A");
                    order.addItem(burgerOrder.getItems().get(0).getItem(), 1);
                    System.out.println("Added Burger. Addons: " + customAddons.size());
                    break;
                }
                customAddons = Arrays.asList(inputLine.split(",")).stream()
                                            .map(String::trim)
                                            .filter(s -> !s.isEmpty())
                                            .collect(Collectors.toList());

                Order burgerOrder = facade.createAndCustomizeOrder(order.getCustomerId(), "ClassicBurger", customAddons, "N/A");
                order.addItem(burgerOrder.getItems().get(0).getItem(), 1);
                System.out.println("Added Burger. Addons: " + customAddons.size());
                break;
                
            case "3": 
                order.addItem(new MenuItem("Chicken Breast Meal", 25.0) {
                    @Override
                    public double calculatePrice() { return getBasePrice(); }
                }, 1);
                System.out.println("Added Chicken Meal.");
                break;
                
            case "4": 
                order.addItem(new MenuItem("Side Salad", 12.0) {
                    @Override
                    public double calculatePrice() { return getBasePrice(); }
                }, 1);
                System.out.println("Added Side Salad.");
                break;

            default:
                throw new OrderException("Invalid menu choice.");
        }
    }
    
    private static String getOrderType() {
        String type;
        while (true) {
            System.out.println("\n--- Order Type ---");
            System.out.print("Choose order type (1-Delivery, 2-Dine-In, 3-Takeaway): ");
            String choice = scanner.nextLine().trim();
            if (choice.equals("1")) {
                type = "Delivery";
                break;
            } else if (choice.equals("2")) {
                type = "Dine-In";
                break;
            } else if (choice.equals("3")) {
                type = "Takeaway";
                break;
            } else {
                System.out.println("[ERROR] Invalid choice. Please enter 1, 2, or 3.");
            }
        }
        return type;
    }
    
    private static IPaymentStrategy getPaymentStrategy() {
        IPaymentStrategy strategy = null;
        while (strategy == null) {
            System.out.println("\n--- Payment Method ---");
            System.out.print("Choose payment (1-Credit Card, 2-Mobile Wallet, 3-Cash): ");
            String choice = scanner.nextLine().trim();
            
            if (choice.equals("1")) {
                System.out.print("Enter Card Number (e.g., 4511 2323 5678 5059): ");
                String cardNumber = scanner.nextLine().trim();
                strategy = new CreditCardPayment(cardNumber);
            } else if (choice.equals("2")) {
                System.out.print("Enter Phone Number (e.g., 555-123-4567): ");
                String phone = scanner.nextLine().trim();
                strategy = new MobileWalletPayment(phone);
            } else if (choice.equals("3")) {
                strategy = new CashPayment();
            } else {
                System.out.println("[ERROR] Invalid payment choice. Please enter 1, 2, or 3.");
            }
        }
        return strategy;
    }
}