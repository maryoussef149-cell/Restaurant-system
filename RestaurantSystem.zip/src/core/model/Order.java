package core.model;

import java.util.ArrayList;
import java.util.List;
import patterns.observer.IOrderObserver;
import patterns.observer.IOrderSubject;

public class Order implements IOrderSubject {
    private String orderId;
    private String customerId;
    private List<OrderLineItem> items = new ArrayList<>();
    private String status = "PENDING";
    private double preDiscountTotal = 0.0;
    private double finalTotal = 0.0;
    private double tax = 0.0;
    private List<String> charges = new ArrayList<>();
    private List<IOrderObserver> observers = new ArrayList<>();

    public Order(String id, String customerId) {
        this.orderId = id;
        this.customerId = customerId;
    }
    
    public void addItem(MenuItem item, int quantity) {
        if (item == null || quantity <= 0) {
            System.err.println("[ERROR] Cannot add null item or zero quantity.");
            return;
        }
        this.items.add(new OrderLineItem(item, quantity));
        updateTotals();
    }
    
    public void updateTotals() {
        double subtotal = items.stream()
                .mapToDouble(i -> i.getItem().calculatePrice() * i.getQuantity())
                .sum();
        this.preDiscountTotal = subtotal;
        this.tax = subtotal * 0.14; 
        this.finalTotal = subtotal + this.tax;
    }
    
    public void addCharge(double amount, String description) {
        this.finalTotal += amount;
        this.charges.add(description + ": +" + amount);
    }

    public double calculateSubTotalByCategory(String category) {
        return items.stream()
                .filter(i -> i.getItem().getName().toLowerCase().contains(category.toLowerCase()))
                .mapToDouble(i -> i.getItem().calculatePrice() * i.getQuantity())
                .sum();
    }
    
    // Observer methods
    @Override
    public void attach(IOrderObserver observer) { observers.add(observer); }
    @Override
    public void detach(IOrderObserver observer) { observers.remove(observer); }
    @Override
    public void notifyObservers() {
        for (IOrderObserver obs : observers) { obs.update(this); }
    }
    
    public void placeOrder() {
        this.status = "PLACED";
        System.out.println("\nOrder " + orderId + " Placed successfully.");
        notifyObservers();
    }

    // Getters
    public List<OrderLineItem> getItems() { return items; }
    public double getPreDiscountTotal() { return preDiscountTotal; }
    public double getFinalTotal() { return finalTotal; }
    public void setFinalTotal(double total) { this.finalTotal = total; }
    public String getStatus() { return status; }
    public String getOrderId() { return orderId; }
    public List<String> getCharges() { return charges; }
    public String getCustomerId() { return customerId; }
    public double getTax() { return tax; }
}