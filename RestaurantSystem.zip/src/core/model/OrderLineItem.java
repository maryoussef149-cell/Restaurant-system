package core.model;

public class OrderLineItem {
    private MenuItem item;
    private int quantity;

    public OrderLineItem(MenuItem item, int quantity) {
        this.item = item;
        this.quantity = quantity;
    }

    public MenuItem getItem() { return item; }
    public int getQuantity() { return quantity; }
}