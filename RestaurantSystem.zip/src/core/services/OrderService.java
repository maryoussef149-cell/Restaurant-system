package core.services;

import core.model.Order;
import core.exceptions.OrderException;

public class OrderService {
    private int orderCounter = 0;

    public Order startNewOrder(String customerId) {
        if (customerId == null || customerId.trim().isEmpty()) {
            throw new OrderException("Customer ID cannot be empty when starting a new order.");
        }
        String orderId = "ORDER-" + (++orderCounter);
        System.out.println("New Order started: " + orderId + " for Customer: " + customerId);
        return new Order(orderId, customerId);
    }
}